ANJANA & HARSH — WEDDING INVITATION WEBSITE

Files
- index.html: complete responsive wedding invitation website.

PREVIEW LOCALLY
1. Download and unzip this folder.
2. Open index.html in a browser (Safari, Chrome, Edge or Firefox).
3. Internet is required for Google Fonts and Google Maps; the main layout works without fonts too.

PERSONALIZE BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Find `const whatsappNumber = '91XXXXXXXXXX';`
3. Replace 91XXXXXXXXXX with the family WhatsApp number including country code, digits only.
   Example format: 919876543210 (use the real number, not this example).
4. Confirm the exact venue location, wedding time, and Haldi/Mehendi dates. These are intentionally marked “to be announced” where details were not provided.
5. Save the file.

PUBLISH FREE WITH GITHUB PAGES
1. Sign in or create an account at https://github.com/
2. Create a new public repository, e.g. anjana-harsh-wedding.
3. Upload index.html to the repository's root (top level) and commit.
4. Open the repository's Settings → Pages.
5. Under Build and deployment, select “Deploy from a branch”, choose branch `main` and folder `/(root)`, then Save.
6. Wait for the deployment to finish. The Pages screen will show the public website URL, usually https://YOUR-USERNAME.github.io/anjana-harsh-wedding/
7. Open that URL on your phone and share it on WhatsApp.

IMPORTANT
- RSVP currently opens WhatsApp with a pre-filled message; it does not store guest responses on a database.
- Do not publish private phone numbers or personal details unless the family agrees.
- The venue link is a Google Maps search for the venue name. Confirm it points to the exact venue before sending invitations.
- Date is set to 24 November 2026. Event times and the exact ceremony time were not provided, so they are not invented.
